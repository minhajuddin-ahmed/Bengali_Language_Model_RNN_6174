# Bangla-Language-Modeling-RNN
To run Bangla_Language_Modeling.ipynb file, Jupyter-Notebook should be used. It consists a sample of 112 sentences where it has been pre-processed accordingly to apply Recurrent Neural Network for Bangla word prediction.

The predicted Bangla word list can be found in Predicted_Bangla_Words.txt file.
